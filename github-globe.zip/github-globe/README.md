# GitHub Globe

A Pen created on CodePen.io. Original URL: [https://codepen.io/joshsalazar/pen/dyzRpEO](https://codepen.io/joshsalazar/pen/dyzRpEO).

Final result for building the GitHub globe. I built this as practice for learning more about Three.js. Thank you to GitHub for the excellent write-up on how they created their GitHub globe.