# AI Slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/chrisgannon/pen/LYXLqpx](https://codepen.io/chrisgannon/pen/LYXLqpx).

The AI robots are back and they won't let you switch them off!

Check out the other animations in my [Bad AI](https://codepen.io/collection/aMKzyp) collection.